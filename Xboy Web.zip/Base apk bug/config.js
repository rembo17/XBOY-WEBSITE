module.exports = {
  tokens: "8239304211:AAEC-YYhJTMsc89XV_U9MQ8wPagahCbWkR0", 
  owner: "8261602791", 
  port: "2003",
  ipvps: "159.65.140.208"
};
